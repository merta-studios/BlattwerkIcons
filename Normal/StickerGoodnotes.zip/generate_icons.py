import os
import glob
import cairosvg

OUT_DIR = "/home/user/icons"
os.makedirs(OUT_DIR, exist_ok=True)

def wrap_svg(body: str, viewbox: str = "0 0 256 256") -> str:
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="{viewbox}" width="256" height="256">
{body}
</svg>'''

ICONS = {}

# ==========================================
# SET 1: IMG_0698 (9 Pastel Flat Shapes - crisp, balanced)
# ==========================================

ICONS["01_cloud"] = wrap_svg('''
  <g fill="#E3E5EA">
    <circle cx="76" cy="142" r="36"/>
    <circle cx="106" cy="96" r="42"/>
    <circle cx="154" cy="92" r="40"/>
    <circle cx="184" cy="136" r="36"/>
    <circle cx="134" cy="148" r="38"/>
    <rect x="74" y="128" width="110" height="48" rx="24"/>
  </g>
''')

ICONS["02_wavy_banner"] = wrap_svg('''
  <path d="M34 66 Q80 90 128 66 T222 66 L222 186 Q176 162 128 186 T34 186 Z" fill="#A6EAF2"/>
''')

ICONS["03_shield_banner"] = wrap_svg('''
  <path d="M52 34 H204 Q212 34 212 42 V174 Q212 180 206 183 L133 221 Q128 223 123 221 L50 183 Q44 180 44 174 V42 Q44 34 52 34 Z" fill="#FACCD1"/>
''')

ICONS["04_star"] = wrap_svg('''
  <path d="M128 30 L153 87 L214 93 Q222 94 216 100 L169 141 L183 202 Q185 210 178 206 L128 174 L78 206 Q71 210 73 202 L87 141 L40 100 Q34 94 42 93 L103 87 Z" fill="#FCE37D" stroke="#FCE37D" stroke-width="10" stroke-linejoin="round"/>
''')

ICONS["05_heart"] = wrap_svg('''
  <path d="M128 216 C128 216 34 154 34 92 C34 56 63 34 94 34 C112 34 123 45 128 56 C133 45 144 34 162 34 C193 34 222 56 222 92 C222 154 128 216 128 216 Z" fill="#FACCD1"/>
''')

ICONS["06_starburst"] = wrap_svg('''
  <path d="M128 32 L152 53 L183 49 L193 78 L219 92 L209 121 L223 147 L199 165 L197 195 L167 197 L147 221 L120 207 L92 217 L78 190 L47 184 L51 154 L31 132 L49 108 L43 78 L73 70 L87 43 L116 53 Z" fill="#BCEB88" stroke="#BCEB88" stroke-width="10" stroke-linejoin="round"/>
''')

ICONS["07_circle"] = wrap_svg('''
  <circle cx="128" cy="128" r="94" fill="#BCEB88"/>
''')

ICONS["08_pill"] = wrap_svg('''
  <rect x="32" y="72" width="192" height="112" rx="56" fill="#A6EAF2"/>
''')

ICONS["09_speech_bubble"] = wrap_svg('''
  <path d="M128 36 C179 36 220 77 220 128 C220 179 179 220 128 220 L50 220 Q36 220 36 206 L36 128 C36 77 77 36 128 36 Z" fill="#A8D8FC"/>
''')

# ==========================================
# SET 2: IMG_0699 (9 Pastel Flat Shapes)
# ==========================================

ICONS["10_rounded_square"] = wrap_svg('''
  <rect x="40" y="40" width="176" height="176" rx="16" fill="#FCE37D"/>
''')

ICONS["11_rounded_rect_horiz"] = wrap_svg('''
  <rect x="32" y="86" width="192" height="84" rx="16" fill="#E3E5EA"/>
''')

ICONS["12_plus_square"] = wrap_svg('''
  <path d="M74 34 H182 Q192 34 192 44 V64 H212 Q222 64 222 74 V182 Q222 192 212 192 H192 V212 Q192 222 182 222 H74 Q64 222 64 212 V192 H44 Q34 192 34 182 V74 Q34 64 44 64 H64 V44 Q64 34 74 34 Z" fill="#A2EBB1"/>
''')

ICONS["13_triangle"] = wrap_svg('''
  <path d="M128 36 L219 207 Q223 215 213 215 L43 215 Q33 215 37 207 Z" fill="#FCE0B8" stroke="#FCE0B8" stroke-width="10" stroke-linejoin="round"/>
''')

ICONS["14_diamond"] = wrap_svg('''
  <path d="M128 44 L216 128 L128 212 L40 128 Z" fill="#A2EBB1" stroke="#A2EBB1" stroke-width="12" stroke-linejoin="round"/>
''')

ICONS["15_hexagon"] = wrap_svg('''
  <path d="M128 32 L214 80 L214 176 L128 224 L42 176 L42 80 Z" fill="#D5C8FA" stroke="#D5C8FA" stroke-width="10" stroke-linejoin="round"/>
''')

ICONS["16_map_pin"] = wrap_svg('''
  <path d="M128 34 C81 34 46 69 46 116 C46 165 128 224 128 224 C128 224 210 165 210 116 C210 69 175 34 128 34 Z" fill="#FACCD1"/>
''')

ICONS["17_bowtie_rect"] = wrap_svg('''
  <path d="M44 54 H212 Q220 54 218 62 L199 128 L218 194 Q220 202 212 202 H44 Q36 202 38 194 L57 128 L38 62 Q36 54 44 54 Z" fill="#D5C8FA"/>
''')

ICONS["18_wavy_ticket"] = wrap_svg('''
  <path d="M42 46 H214 Q222 46 222 54 V198 Q176 175 130 198 T34 198 V54 Q34 46 42 46 Z" fill="#FCE0B8"/>
''')

# ==========================================
# SET 3: IMG_0701 (2 Pastel Flat Shapes)
# ==========================================

ICONS["19_folder"] = wrap_svg('''
  <path d="M34 50 Q34 40 44 40 H92 Q100 40 106 48 L117 64 H210 Q220 64 220 74 V202 Q220 212 210 212 H44 Q34 212 34 202 Z" fill="#B6E1FC"/>
''')

ICONS["20_cursor"] = wrap_svg('''
  <path d="M56 40 L208 128 Q216 133 207 138 L142 157 L113 216 Q108 224 102 215 L46 50 Q43 40 56 40 Z" fill="#E3E5EA"/>
''')

# ==========================================
# SET 4: IMG_0702 (9 Organic Hand-Drawn School Doodles)
# ==========================================

ICONS["21_pen_heart"] = wrap_svg('''
  <!-- Soft yellow glow behind heart -->
  <circle cx="72" cy="54" r="30" fill="#FEF08A" opacity="0.5"/>
  <!-- Organic Heart -->
  <path d="M72 84 C70 82 42 64 42 46 C42 35 52 28 62 29 C68 30 71 34 72 38 C74 34 77 30 83 29 C93 28 102 35 102 46 C102 64 74 82 72 84 Z" fill="#FA7268"/>
  <!-- Pen (organic marker style) -->
  <g transform="rotate(34 142 132)">
    <path d="M116 66 C116 48 128 38 142 38 C156 38 168 48 168 66 L166 184 C166 196 156 204 142 204 C128 204 118 196 118 184 Z" fill="#4B79B8"/>
    <path d="M126 54 C126 48 132 45 138 45" fill="none" stroke="#93C5FD" stroke-width="5" stroke-linecap="round" opacity="0.7"/>
    <path d="M124 198 L142 224 L160 198 Z" fill="#4B79B8"/>
    <path d="M116 108 Q142 112 168 106" fill="none" stroke="#1E293B" stroke-width="5" stroke-linecap="round"/>
    <circle cx="133" cy="76" r="4" fill="#1E293B"/>
    <circle cx="151" cy="76" r="4" fill="#1E293B"/>
    <path d="M132 88 Q142 97 152 87" fill="none" stroke="#1E293B" stroke-width="4" stroke-linecap="round"/>
  </g>
  <!-- Hand-drawn squiggle -->
  <path d="M96 216 Q114 224 134 212 T174 214" fill="none" stroke="#1E293B" stroke-width="6" stroke-linecap="round"/>
''')

ICONS["22_apple_worm"] = wrap_svg('''
  <!-- Stem & leaf -->
  <path d="M126 72 Q125 44 139 30" fill="none" stroke="#1E293B" stroke-width="6" stroke-linecap="round"/>
  <path d="M132 50 Q162 26 180 46 Q160 68 132 50 Z" fill="#A2EBB1"/>
  <!-- Apple -->
  <path d="M128 74 C94 56 46 80 46 134 C46 188 86 218 114 218 C122 218 126 213 128 211 C130 213 134 218 142 218 C170 218 210 188 210 134 C210 80 162 56 128 74 Z" fill="#FF5252"/>
  <!-- Highlight -->
  <path d="M68 106 Q78 86 96 82" fill="none" stroke="#FCA5A5" stroke-width="6" stroke-linecap="round" opacity="0.6"/>
  <!-- Speckles -->
  <circle cx="76" cy="148" r="2.5" fill="#7F1D1D"/>
  <circle cx="88" cy="160" r="2.5" fill="#7F1D1D"/>
  <circle cx="72" cy="166" r="2.5" fill="#7F1D1D"/>
  <circle cx="96" cy="146" r="2" fill="#7F1D1D"/>
  <!-- Worm hole -->
  <ellipse cx="168" cy="126" rx="21" ry="15" fill="#1E293B"/>
  <!-- Worm -->
  <path d="M166 126 Q168 90 187 84 Q206 78 208 96 Q210 112 190 110 Q182 110 180 125" fill="#FFFFFF" stroke="#1E293B" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
  <circle cx="189" cy="91" r="2.5" fill="#1E293B"/>
  <circle cx="198" cy="91" r="2.5" fill="#1E293B"/>
  <path d="M191 98 Q194 102 198 98" fill="none" stroke="#1E293B" stroke-width="2.5" stroke-linecap="round"/>
''')

ICONS["23_glasses"] = wrap_svg('''
  <!-- Lenses -->
  <circle cx="80" cy="136" r="37" fill="#CFE8FF" opacity="0.85"/>
  <circle cx="176" cy="144" r="37" fill="#CFE8FF" opacity="0.85"/>
  <!-- Lens glare -->
  <path d="M58 118 Q68 108 82 108" fill="none" stroke="#FFFFFF" stroke-width="5" stroke-linecap="round"/>
  <path d="M154 126 Q164 116 178 116" fill="none" stroke="#FFFFFF" stroke-width="5" stroke-linecap="round"/>
  <!-- Frame -->
  <path d="M38 122 Q38 96 68 96 Q104 96 112 122 L144 128 Q152 102 186 102 Q216 102 216 128" fill="none" stroke="#1E293B" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/>
  <!-- Arms -->
  <path d="M38 118 L22 94 Q18 88 26 82 L54 74" fill="none" stroke="#1E293B" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M216 124 L236 114" fill="none" stroke="#1E293B" stroke-width="9" stroke-linecap="round"/>
''')

ICONS["24_checklist_100"] = wrap_svg('''
  <rect x="44" y="46" width="126" height="158" rx="16" fill="#CFE8FF" opacity="0.9"/>
  <rect x="78" y="64" width="126" height="158" rx="16" fill="#FEF08A" opacity="0.55"/>
  <!-- Checkmarks & squiggles -->
  <path d="M66 88 L75 97 L93 77" fill="none" stroke="#1E293B" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M104 90 Q114 82 124 90 T146 90" fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round"/>
  <path d="M66 128 L75 137 L93 117" fill="none" stroke="#1E293B" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M104 130 Q114 122 124 130 T146 130" fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round"/>
  <path d="M66 168 L75 177 L93 157" fill="none" stroke="#1E293B" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M104 170 Q114 162 124 170 T146 170" fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round"/>
  <!-- 100 -->
  <text x="148" y="84" font-family="Comic Sans MS, Arial, sans-serif" font-weight="bold" font-size="34" fill="#EF4444" transform="rotate(12 165 75)">100</text>
  <line x1="146" y1="92" x2="196" y2="100" stroke="#EF4444" stroke-width="5" stroke-linecap="round"/>
  <line x1="150" y1="102" x2="190" y2="108" stroke="#EF4444" stroke-width="4" stroke-linecap="round"/>
''')

ICONS["25_laptop_smile"] = wrap_svg('''
  <!-- Screen -->
  <rect x="52" y="56" width="136" height="92" rx="10" fill="#9CA3AF" transform="rotate(-10 120 102)"/>
  <rect x="64" y="68" width="112" height="68" rx="6" fill="#FFFFFF" transform="rotate(-10 120 102)"/>
  <!-- Sidebar dots on screen -->
  <rect x="70" y="92" width="18" height="6" rx="3" fill="#A2EBB1" transform="rotate(-10 79 95)"/>
  <rect x="72" y="104" width="14" height="6" rx="3" fill="#FDE047" transform="rotate(-10 79 107)"/>
  <rect x="74" y="116" width="10" height="6" rx="3" fill="#FCA5A5" transform="rotate(-10 79 119)"/>
  <!-- Smiley -->
  <circle cx="112" cy="96" r="4" fill="#1E293B"/>
  <circle cx="134" cy="92" r="4" fill="#1E293B"/>
  <path d="M114 108 Q124 116 136 104" fill="none" stroke="#1E293B" stroke-width="4" stroke-linecap="round"/>
  <!-- Base & keyboard -->
  <path d="M58 156 L186 134 L214 178 Q218 184 210 186 L96 208 Q88 210 84 202 Z" fill="#D1D5DB" stroke="#1E293B" stroke-width="4" stroke-linejoin="round"/>
  <g fill="#9CA3AF">
    <circle cx="96" cy="162" r="3"/><circle cx="110" cy="160" r="3"/><circle cx="124" cy="157" r="3"/><circle cx="138" cy="155" r="3"/><circle cx="152" cy="152" r="3"/>
    <circle cx="102" cy="172" r="3"/><circle cx="116" cy="170" r="3"/><circle cx="130" cy="167" r="3"/><circle cx="144" cy="165" r="3"/><circle cx="158" cy="162" r="3"/>
  </g>
  <rect x="130" y="174" width="34" height="18" rx="4" fill="#6B7280" transform="rotate(-10 147 183)"/>
  <!-- White digital stylus pen on top -->
  <g transform="rotate(-8 110 46)">
    <path d="M62 46 L78 39 L154 39 Q160 39 160 46 Q160 53 154 53 L78 53 Z" fill="#FFFFFF" stroke="#1E293B" stroke-width="5" stroke-linejoin="round"/>
    <circle cx="62" cy="46" r="2.5" fill="#1E293B"/>
  </g>
''')

ICONS["26_bookmark_surprised"] = wrap_svg('''
  <line x1="68" y1="74" x2="52" y2="60" stroke="#1E293B" stroke-width="5" stroke-linecap="round"/>
  <line x1="56" y1="96" x2="38" y2="96" stroke="#1E293B" stroke-width="5" stroke-linecap="round"/>
  <line x1="92" y1="54" x2="90" y2="36" stroke="#1E293B" stroke-width="5" stroke-linecap="round"/>
  <path d="M96 86 H188 Q196 86 196 96 V206 L142 178 L96 206 Z" fill="#FDBA74" opacity="0.6"/>
  <path d="M86 74 H182 Q192 74 192 84 V196 L139 168 L86 196 V84 Q86 74 86 74 Z" fill="#FA7268" opacity="0.9"/>
  <circle cx="126" cy="114" r="4" fill="#1E293B"/>
  <circle cx="152" cy="112" r="4" fill="#1E293B"/>
  <ellipse cx="139" cy="128" rx="6" ry="8" fill="none" stroke="#1E293B" stroke-width="4"/>
''')

ICONS["27_chem_book"] = wrap_svg('''
  <circle cx="152" cy="48" r="8" fill="#A6EAF2"/>
  <circle cx="176" cy="44" r="7" fill="#FDE047"/>
  <circle cx="198" cy="54" r="8" fill="#FACCD1"/>
  <circle cx="206" cy="76" r="7" fill="#FDBA74"/>
  <rect x="58" y="66" width="116" height="148" rx="12" fill="#6EE76E" transform="rotate(6 116 140)"/>
  <path d="M62 196 H162 Q168 196 168 202 V210 H62 Q54 210 54 203 Z" fill="#E5E7EB" transform="rotate(6 116 203)"/>
  <g transform="translate(118, 122)">
    <ellipse cx="0" cy="0" rx="30" ry="12" fill="none" stroke="#FFFFFF" stroke-width="3" transform="rotate(30)"/>
    <ellipse cx="0" cy="0" rx="30" ry="12" fill="none" stroke="#FFFFFF" stroke-width="3" transform="rotate(-30)"/>
    <ellipse cx="0" cy="0" rx="30" ry="12" fill="none" stroke="#FFFFFF" stroke-width="3" transform="rotate(90)"/>
    <circle cx="0" cy="0" r="6" fill="#FFFFFF"/>
  </g>
  <text x="72" y="186" font-family="Arial, sans-serif" font-weight="bold" font-size="28" fill="#1E293B" transform="rotate(6 110 180)">CHEM</text>
''')

ICONS["28_leaf_magnifier"] = wrap_svg('''
  <path d="M64 186 Q64 96 172 72 Q164 166 64 186 Z" fill="#6EE76E"/>
  <path d="M64 186 Q106 138 142 104" fill="none" stroke="#1E293B" stroke-width="5" stroke-linecap="round"/>
  <path d="M104 146 L104 124 M120 128 L120 108 M104 146 L128 146" fill="none" stroke="#1E293B" stroke-width="4" stroke-linecap="round"/>
  <circle cx="118" cy="122" r="56" fill="#CFE8FF" fill-opacity="0.35" stroke="#9CA3AF" stroke-width="10"/>
  <path d="M74 96 A54 54 0 0 1 156 84" fill="none" stroke="#1E293B" stroke-width="5" stroke-linecap="round"/>
  <line x1="158" y1="164" x2="200" y2="206" stroke="#1E293B" stroke-width="18" stroke-linecap="round"/>
''')

ICONS["29_math_folder"] = wrap_svg('''
  <path d="M42 74 Q42 62 54 62 H96 Q104 62 110 70 L120 82 H198 Q210 82 210 94 V178 Q210 190 198 190 H54 Q42 190 42 178 Z" fill="#CFE8FF"/>
  <path d="M198 76 L204 88 L218 90 L208 99 L210 112 L198 106 L186 112 L188 99 L178 90 L192 88 Z" fill="#FA7268"/>
  <circle cx="104" cy="126" r="4" fill="#1E293B"/>
  <circle cx="144" cy="126" r="4" fill="#1E293B"/>
  <path d="M108 146 Q124 156 140 146" fill="none" stroke="#1E293B" stroke-width="5" stroke-linecap="round"/>
  <text x="80" y="224" font-family="Arial, sans-serif" font-weight="bold" font-size="30" fill="#1E293B">MATH</text>
''')

# ==========================================
# SET 5: IMG_0703 (3 Organic School Doodles)
# ==========================================

ICONS["30_ruler_leaf"] = wrap_svg('''
  <path d="M138 186 Q96 150 104 108 Q128 118 134 94 Q158 56 172 78 Q192 98 206 106 Q192 134 210 148 Q190 182 138 186 Z" fill="#FCD38D"/>
  <path d="M148 210 L166 112 M156 164 L136 144 M160 142 L182 130" fill="none" stroke="#1E293B" stroke-width="5" stroke-linecap="round"/>
  <rect x="52" y="42" width="46" height="176" rx="8" fill="#B6E1FC" transform="rotate(-6 75 130)"/>
  <g stroke="#1E293B" stroke-width="5" stroke-linecap="round">
    <line x1="88" y1="68" x2="74" y2="70"/>
    <line x1="90" y1="90" x2="80" y2="91"/>
    <line x1="92" y1="112" x2="72" y2="114"/>
    <line x1="94" y1="134" x2="84" y2="135"/>
    <line x1="96" y1="156" x2="74" y2="158"/>
    <line x1="98" y1="178" x2="86" y2="179"/>
  </g>
''')

ICONS["31_basketball_tennis"] = wrap_svg('''
  <circle cx="122" cy="120" r="82" fill="#FF7043"/>
  <path d="M46 92 Q122 124 198 112" fill="none" stroke="#1E293B" stroke-width="6" stroke-linecap="round"/>
  <path d="M52 152 Q122 130 192 162" fill="none" stroke="#1E293B" stroke-width="6" stroke-linecap="round"/>
  <path d="M96 42 Q66 120 96 198" fill="none" stroke="#1E293B" stroke-width="6" stroke-linecap="round"/>
  <circle cx="192" cy="186" r="24" fill="#E6EE9C"/>
  <path d="M174 176 Q188 186 176 198 M208 174 Q196 186 208 198" fill="none" stroke="#1E293B" stroke-width="3.5" stroke-linecap="round"/>
''')

ICONS["32_eraser"] = wrap_svg('''
  <g transform="rotate(34 132 114)">
    <rect x="86" y="48" width="92" height="128" rx="18" fill="#60A5FA"/>
    <rect x="132" y="48" width="46" height="128" rx="18" fill="#3B82F6"/>
  </g>
  <path d="M68 158 Q46 184 82 204 L126 204 M104 204 L118 190" fill="none" stroke="#1E293B" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
''')

# ==========================================
# SET 6: IMG_0704 (9 Blue-Outlined Stickers)
# ==========================================

ICONS["33_basketball_motion"] = wrap_svg('''
  <circle cx="140" cy="116" r="76" fill="#FFB36B"/>
  <path d="M92 56 Q146 116 114 186 M72 138 Q140 100 208 134 M124 42 Q178 86 196 164" fill="none" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <line x1="42" y1="184" x2="66" y2="164" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <line x1="58" y1="204" x2="88" y2="180" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
''')

ICONS["34_bicycle"] = wrap_svg('''
  <circle cx="68" cy="156" r="26" fill="none" stroke="#374151" stroke-width="14"/>
  <circle cx="68" cy="156" r="8" fill="#FFFFFF"/>
  <circle cx="186" cy="164" r="26" fill="none" stroke="#374151" stroke-width="14"/>
  <circle cx="186" cy="164" r="8" fill="#FFFFFF"/>
  <path d="M68 156 L114 106 L166 112 L134 162 Z" fill="none" stroke="#3B82F6" stroke-width="6" stroke-linejoin="round"/>
  <path d="M166 112 L186 164 M114 106 L86 82 L100 82" fill="none" stroke="#3B82F6" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M154 98 H182" stroke="#FFB36B" stroke-width="8" stroke-linecap="round"/>
  <line x1="204" y1="196" x2="224" y2="198" stroke="#3B82F6" stroke-width="4" stroke-linecap="round"/>
''')

ICONS["35_yoga_mat"] = wrap_svg('''
  <!-- Unrolled mat perspective -->
  <path d="M52 138 L138 112 L226 132 L182 182 L58 178 Z" fill="#A7F3A0" stroke="#3B82F6" stroke-width="5" stroke-linejoin="round"/>
  <!-- Rolled-up left cylinder -->
  <path d="M58 178 C36 178 32 146 52 138 L94 126 C78 134 80 166 98 168 Z" fill="#86EFAC" stroke="#3B82F6" stroke-width="5" stroke-linejoin="round"/>
  <ellipse cx="56" cy="158" rx="18" ry="20" fill="#A7F3A0" stroke="#3B82F6" stroke-width="5"/>
  <!-- Spiral inside roll -->
  <path d="M56 158 m-9 0 a9 9 0 1 0 18 0 a6 6 0 1 0 -12 0 a3 3 0 1 0 6 0" fill="none" stroke="#3B82F6" stroke-width="3.5" stroke-linecap="round"/>
  <!-- Dumbbells resting on mat -->
  <g stroke="#3B82F6" stroke-width="3" fill="#FB7185">
    <line x1="122" y1="128" x2="152" y2="148" stroke="#FB7185" stroke-width="9" stroke-linecap="round"/>
    <circle cx="118" cy="125" r="8"/><circle cx="155" cy="150" r="8"/>
    <line x1="166" y1="124" x2="198" y2="138" stroke="#FB7185" stroke-width="9" stroke-linecap="round"/>
    <circle cx="163" cy="122" r="8"/><circle cx="201" cy="140" r="8"/>
  </g>
''')

ICONS["36_map_magnifier"] = wrap_svg('''
  <!-- Folded Map -->
  <path d="M38 74 L92 54 L138 74 L190 56 L212 148 L154 166 L108 146 L54 166 Z" fill="#FFFFFF" stroke="#3B82F6" stroke-width="5" stroke-linejoin="round"/>
  <!-- Fold creases -->
  <line x1="92" y1="54" x2="108" y2="146" stroke="#93C5FD" stroke-width="3"/>
  <line x1="138" y1="74" x2="154" y2="166" stroke="#93C5FD" stroke-width="3"/>
  <!-- Green parks -->
  <path d="M52 94 L84 84 L90 112 L58 122 Z" fill="#A7F3A0"/>
  <path d="M124 118 L168 108 L176 138 L132 148 Z" fill="#A7F3A0"/>
  <!-- Roads & River -->
  <path d="M46 116 L198 88" stroke="#FDE047" stroke-width="9" stroke-linecap="round"/>
  <path d="M114 66 L126 152" stroke="#A6EAF2" stroke-width="9" stroke-linecap="round"/>
  <!-- Little building blocks -->
  <rect x="64" y="132" width="14" height="10" rx="2" fill="none" stroke="#64748B" stroke-width="2.5"/>
  <rect x="102" y="82" width="12" height="10" rx="2" fill="none" stroke="#64748B" stroke-width="2.5"/>
  <rect x="156" y="72" width="16" height="10" rx="2" fill="none" stroke="#64748B" stroke-width="2.5"/>
  <!-- Magnifying glass -->
  <circle cx="158" cy="132" r="28" fill="#FFFFFF" fill-opacity="0.75" stroke="#3B82F6" stroke-width="6"/>
  <path d="M144 120 A18 18 0 0 1 166 114" fill="none" stroke="#93C5FD" stroke-width="4" stroke-linecap="round"/>
  <line x1="178" y1="152" x2="210" y2="188" stroke="#F472B6" stroke-width="12" stroke-linecap="round"/>
  <line x1="178" y1="152" x2="210" y2="188" stroke="#3B82F6" stroke-width="2" stroke-linecap="round"/>
''')

ICONS["37_cassette"] = wrap_svg('''
  <g transform="rotate(-4 128 127)">
    <rect x="42" y="66" width="172" height="122" rx="14" fill="#FB7185" stroke="#3B82F6" stroke-width="5"/>
    <!-- Top zig-zag -->
    <path d="M104 82 L112 76 L120 82 L128 76 L136 82 L144 76 L152 82" fill="none" stroke="#FFFFFF" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
    <!-- Label -->
    <rect x="62" y="94" width="132" height="62" rx="6" fill="#FFFFFF" stroke="#3B82F6" stroke-width="4"/>
    <!-- Reels -->
    <circle cx="96" cy="125" r="17" fill="#374151"/>
    <circle cx="96" cy="125" r="7" fill="#FFFFFF"/>
    <circle cx="158" cy="125" r="15" fill="#374151"/>
    <circle cx="158" cy="125" r="6" fill="#FFFFFF"/>
    <!-- Bottom trapezoid -->
    <path d="M84 188 L94 166 H162 L172 188 Z" fill="#E5E7EB" stroke="#3B82F6" stroke-width="3"/>
  </g>
''')

ICONS["38_camera"] = wrap_svg('''
  <!-- Shutter & flash -->
  <rect x="68" y="64" width="22" height="12" rx="3" fill="#9CA3AF" stroke="#3B82F6" stroke-width="3"/>
  <rect x="164" y="64" width="28" height="12" rx="3" fill="#9CA3AF" stroke="#3B82F6" stroke-width="3"/>
  <!-- Body -->
  <rect x="42" y="76" width="168" height="114" rx="12" fill="#E5E7EB" stroke="#3B82F6" stroke-width="5"/>
  <rect x="42" y="106" width="168" height="72" fill="#374151"/>
  <!-- Zig-zag grip & viewfinder -->
  <path d="M54 90 L60 85 L66 90 L72 85 L78 90 L84 85" fill="none" stroke="#1E293B" stroke-width="2.5" stroke-linecap="round"/>
  <rect x="148" y="84" width="18" height="12" rx="2" fill="#FFFFFF" stroke="#3B82F6" stroke-width="2.5"/>
  <rect x="174" y="84" width="22" height="12" rx="2" fill="#FFFFFF" stroke="#3B82F6" stroke-width="2.5"/>
  <!-- Lens -->
  <circle cx="126" cy="140" r="35" fill="#1F2937" stroke="#FFFFFF" stroke-width="5"/>
  <circle cx="126" cy="140" r="23" fill="#374151"/>
  <path d="M112 126 A16 16 0 0 1 136 122" fill="none" stroke="#93C5FD" stroke-width="3" stroke-linecap="round"/>
  <!-- Sparkle -->
  <path d="M220 46 L224 56 L234 60 L224 64 L220 74 L216 64 L206 60 L216 56 Z" fill="none" stroke="#3B82F6" stroke-width="3" stroke-linejoin="round"/>
''')

ICONS["39_tablet_paw"] = wrap_svg('''
  <g transform="rotate(8 116 134)">
    <rect x="50" y="54" width="132" height="160" rx="18" fill="#A7F3D0" stroke="#3B82F6" stroke-width="5"/>
    <rect x="64" y="72" width="104" height="116" rx="8" fill="#FFFFFF"/>
    <!-- Status dots -->
    <circle cx="74" cy="80" r="2" fill="#3B82F6"/><circle cx="80" cy="80" r="2" fill="#3B82F6"/><circle cx="86" cy="80" r="2" fill="#3B82F6"/>
    <!-- Home button -->
    <circle cx="116" cy="200" r="6" fill="#FFFFFF"/>
  </g>
  <!-- Paw print -->
  <ellipse cx="110" cy="126" rx="13" ry="10" fill="#3B82F6"/>
  <circle cx="96" cy="110" r="5" fill="#3B82F6"/>
  <circle cx="110" cy="105" r="5" fill="#3B82F6"/>
  <circle cx="124" cy="111" r="5" fill="#3B82F6"/>
  <!-- Cat paw -->
  <path d="M216 148 L164 190 Q142 198 136 178 Q132 158 154 148 L198 122" fill="#FEF3C7" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <circle cx="152" cy="172" r="5" fill="#FDBA74"/>
''')

ICONS["40_table_books"] = wrap_svg('''
  <!-- Table leg -->
  <path d="M128 164 V216 M128 210 Q108 224 96 214 M128 210 Q148 224 160 214" fill="none" stroke="#A16207" stroke-width="8" stroke-linecap="round"/>
  <!-- Table top -->
  <ellipse cx="128" cy="136" rx="88" ry="42" fill="#FFFFFF" stroke="#3B82F6" stroke-width="5"/>
  <!-- Books with pages -->
  <rect x="110" y="92" width="72" height="32" rx="6" fill="#FB923C" stroke="#3B82F6" stroke-width="4"/>
  <line x1="122" y1="108" x2="170" y2="108" stroke="#FFFFFF" stroke-width="5" stroke-linecap="round"/>
  <rect x="122" y="64" width="66" height="28" rx="6" fill="#6EE76E" stroke="#3B82F6" stroke-width="4"/>
  <line x1="134" y1="78" x2="176" y2="78" stroke="#FFFFFF" stroke-width="5" stroke-linecap="round"/>
  <!-- Glasses -->
  <circle cx="78" cy="136" r="10" fill="none" stroke="#3B82F6" stroke-width="3.5"/>
  <circle cx="104" cy="140" r="10" fill="none" stroke="#3B82F6" stroke-width="3.5"/>
  <line x1="88" y1="138" x2="94" y2="138" stroke="#3B82F6" stroke-width="3.5"/>
''')

ICONS["41_potted_plant"] = wrap_svg('''
  <!-- Pot -->
  <path d="M96 168 H160 L150 218 H106 Z" fill="#FFFFFF" stroke="#3B82F6" stroke-width="5" stroke-linejoin="round"/>
  <rect x="90" y="156" width="76" height="14" rx="4" fill="#FFFFFF" stroke="#3B82F6" stroke-width="5"/>
  <!-- Stem & leaves -->
  <path d="M128 156 V76" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <ellipse cx="102" cy="114" rx="22" ry="11" fill="#BEF264" stroke="#F472B6" stroke-width="3" transform="rotate(-20 102 114)"/>
  <ellipse cx="154" cy="100" rx="22" ry="11" fill="#BEF264" stroke="#F472B6" stroke-width="3" transform="rotate(20 154 100)"/>
  <ellipse cx="108" cy="84" rx="16" ry="8" fill="#BEF264" stroke="#F472B6" stroke-width="3" transform="rotate(-15 108 84)"/>
  <!-- Butterflies -->
  <g fill="#FB923C">
    <circle cx="144" cy="64" r="7"/><circle cx="154" cy="62" r="7"/>
    <circle cx="180" cy="48" r="7"/><circle cx="190" cy="46" r="7"/>
  </g>
''')

# ==========================================
# SET 7: IMG_0705 (9 Blue-Outlined Home/Food)
# ==========================================

ICONS["42_sofa_lamp"] = wrap_svg('''
  <!-- Lamp -->
  <line x1="198" y1="112" x2="198" y2="190" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <line x1="184" y1="190" x2="212" y2="190" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <path d="M180 112 L188 74 H208 L216 112 Z" fill="#FCE7F3" stroke="#3B82F6" stroke-width="4" stroke-linejoin="round"/>
  <!-- Sofa -->
  <rect x="44" y="114" width="132" height="58" rx="14" fill="#FDE047" stroke="#3B82F6" stroke-width="5"/>
  <rect x="34" y="136" width="22" height="36" rx="8" fill="#FDE047" stroke="#3B82F6" stroke-width="5"/>
  <rect x="164" y="136" width="22" height="36" rx="8" fill="#FDE047" stroke="#3B82F6" stroke-width="5"/>
  <line x1="58" y1="172" x2="58" y2="184" stroke="#FDE047" stroke-width="6" stroke-linecap="round"/>
  <line x1="162" y1="172" x2="162" y2="184" stroke="#FDE047" stroke-width="6" stroke-linecap="round"/>
  <rect x="64" y="124" width="24" height="24" rx="4" fill="#FB923C" transform="rotate(15 76 136)"/>
''')

ICONS["43_bathtub"] = wrap_svg('''
  <!-- Tub -->
  <path d="M44 128 H212 C212 168 186 190 128 190 C70 190 44 168 44 128 Z" fill="#FFFFFF" stroke="#3B82F6" stroke-width="5"/>
  <circle cx="68" cy="194" r="5" fill="#3B82F6"/><circle cx="188" cy="194" r="5" fill="#3B82F6"/>
  <!-- Bubbles -->
  <circle cx="152" cy="112" r="18" fill="#FFFFFF" stroke="#3B82F6" stroke-width="4"/>
  <circle cx="176" cy="118" r="14" fill="#FFFFFF" stroke="#3B82F6" stroke-width="4"/>
  <circle cx="192" cy="86" r="6" fill="none" stroke="#3B82F6" stroke-width="3"/>
  <!-- Duck -->
  <circle cx="88" cy="116" r="12" fill="#FDE047"/>
  <path d="M74 116 L68 118 L74 121 Z" fill="#FB923C"/>
  <!-- Towel -->
  <rect x="134" y="132" width="28" height="40" rx="6" fill="#FBCFE8" stroke="#3B82F6" stroke-width="4"/>
  <line x1="142" y1="142" x2="142" y2="164" stroke="#3B82F6" stroke-width="2.5" stroke-linecap="round"/>
''')

ICONS["44_cereal_milk"] = wrap_svg('''
  <path d="M62 124 H162 C162 152 138 164 112 164 C86 164 62 152 62 124 Z" fill="#FFFFFF" stroke="#3B82F6" stroke-width="5"/>
  <!-- Berries -->
  <circle cx="96" cy="120" r="4" fill="#EF4444"/><circle cx="112" cy="118" r="4" fill="#3B82F6"/><circle cx="128" cy="120" r="4" fill="#EF4444"/>
  <!-- Banana -->
  <path d="M38 158 Q74 196 132 184 Q88 176 48 152 Z" fill="#FDE047" stroke="#3B82F6" stroke-width="4"/>
  <!-- Milk bottle -->
  <rect x="172" y="84" width="44" height="96" rx="10" fill="#FFFFFF" stroke="#3B82F6" stroke-width="5"/>
  <rect x="178" y="76" width="32" height="10" rx="3" fill="#FFFFFF" stroke="#3B82F6" stroke-width="4"/>
  <text x="178" y="144" font-family="Arial, sans-serif" font-weight="bold" font-size="14" fill="#3B82F6">Milk</text>
''')

ICONS["45_coffee_cookies"] = wrap_svg('''
  <ellipse cx="132" cy="164" rx="76" ry="20" fill="#E5E7EB"/>
  <path d="M68 106 H178 C178 144 154 160 123 160 C92 160 68 144 68 106 Z" fill="#FFFFFF" stroke="#3B82F6" stroke-width="5"/>
  <path d="M178 118 C196 118 196 142 174 146" fill="none" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <ellipse cx="123" cy="106" rx="55" ry="16" fill="#FFFFFF" stroke="#3B82F6" stroke-width="5"/>
  <ellipse cx="123" cy="108" rx="42" ry="10" fill="#78350F"/>
  <!-- Cookies with chips -->
  <circle cx="64" cy="156" r="18" fill="#FDE68A" stroke="#3B82F6" stroke-width="4"/>
  <circle cx="58" cy="152" r="2.5" fill="#78350F"/><circle cx="68" cy="160" r="2.5" fill="#78350F"/>
  <circle cx="92" cy="166" r="18" fill="#FDE68A" stroke="#3B82F6" stroke-width="4"/>
  <circle cx="88" cy="162" r="2.5" fill="#78350F"/><circle cx="98" cy="170" r="2.5" fill="#78350F"/>
''')

ICONS["46_teapot"] = wrap_svg('''
  <path d="M96 86 H168 C184 118 184 164 164 192 H100 C80 164 80 118 96 86 Z" fill="#FFFFFF" stroke="#3B82F6" stroke-width="5"/>
  <path d="M116 86 Q132 68 148 86" fill="#FFFFFF" stroke="#3B82F6" stroke-width="4"/>
  <circle cx="118" cy="106" r="3" fill="#3B82F6"/><circle cx="132" cy="106" r="3" fill="#3B82F6"/><circle cx="146" cy="106" r="3" fill="#3B82F6"/>
  <path d="M168 108 C196 108 196 144 172 154" fill="none" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <path d="M88 136 L62 112" fill="none" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <path d="M46 154 H96 C96 176 82 184 71 184 C60 184 46 176 46 154 Z" fill="#FCE7F3" stroke="#3B82F6" stroke-width="4"/>
  <ellipse cx="71" cy="188" rx="30" ry="6" fill="#FCE7F3" stroke="#3B82F6" stroke-width="3"/>
''')

ICONS["47_spaghetti"] = wrap_svg('''
  <ellipse cx="128" cy="156" rx="88" ry="22" fill="#FFFFFF" stroke="#3B82F6" stroke-width="5"/>
  <path d="M64 148 Q128 96 192 148 Z" fill="#FDE68A"/>
  <path d="M74 144 Q128 108 182 144" fill="none" stroke="#EF4444" stroke-width="6" stroke-linecap="round"/>
  <path d="M82 136 Q128 116 174 136" fill="none" stroke="#F59E0B" stroke-width="4" stroke-linecap="round"/>
  <circle cx="98" cy="126" r="10" fill="#9A3412"/>
  <circle cx="128" cy="114" r="10" fill="#9A3412"/>
  <circle cx="154" cy="130" r="10" fill="#9A3412"/>
''')

ICONS["48_ice_cream"] = wrap_svg('''
  <path d="M48 202 Q68 156 118 164 Q168 172 188 204 Z" fill="#FEF3C7" stroke="#3B82F6" stroke-width="5"/>
  <circle cx="96" cy="184" r="3" fill="#78350F"/><circle cx="124" cy="188" r="3" fill="#78350F"/><circle cx="148" cy="182" r="3" fill="#78350F"/>
  <path d="M44 48 L128 112 L76 164 Z" fill="#B45309" stroke="#3B82F6" stroke-width="5" stroke-linejoin="round"/>
  <line x1="64" y1="84" x2="96" y2="128" stroke="#FEF3C7" stroke-width="3" stroke-linecap="round"/>
  <line x1="80" y1="78" x2="108" y2="116" stroke="#FEF3C7" stroke-width="3" stroke-linecap="round"/>
''')

ICONS["49_cocktail"] = wrap_svg('''
  <path d="M54 68 H186 L120 144 Z" fill="#FFFFFF" stroke="#3B82F6" stroke-width="5" stroke-linejoin="round"/>
  <path d="M72 80 H168 L120 130 Z" fill="#FB7185"/>
  <line x1="120" y1="144" x2="120" y2="208" stroke="#3B82F6" stroke-width="6"/>
  <line x1="88" y1="208" x2="152" y2="208" stroke="#3B82F6" stroke-width="6" stroke-linecap="round"/>
  <circle cx="182" cy="72" r="22" fill="#BEF264" stroke="#3B82F6" stroke-width="4"/>
  <circle cx="182" cy="72" r="14" fill="#FEF08A"/>
''')

ICONS["50_balloons"] = wrap_svg('''
  <path d="M98 164 Q108 190 98 214" fill="none" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <path d="M156 150 Q166 178 156 204" fill="none" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <ellipse cx="98" cy="120" rx="38" ry="44" fill="#BEF264"/>
  <path d="M78 96 Q84 84 96 84" fill="none" stroke="#FFFFFF" stroke-width="4" stroke-linecap="round"/>
  <ellipse cx="156" cy="100" rx="40" ry="46" fill="#F9A8D4"/>
  <path d="M136 76 Q142 64 154 64" fill="none" stroke="#FFFFFF" stroke-width="4" stroke-linecap="round"/>
''')

# ==========================================
# SET 8: IMG_0706 (9 Blue-Outlined Party/Hands)
# ==========================================

ICONS["51_party_hat"] = wrap_svg('''
  <path d="M128 46 L72 184 Q128 210 184 184 Z" fill="#FDE047" stroke="#3B82F6" stroke-width="6" stroke-linejoin="round"/>
  <path d="M104 106 Q128 118 152 106" fill="none" stroke="#FB923C" stroke-width="6" stroke-linecap="round"/>
  <path d="M88 144 Q128 160 168 144" fill="none" stroke="#FB923C" stroke-width="6" stroke-linecap="round"/>
  <circle cx="128" cy="40" r="10" fill="#FB923C"/>
  <path d="M44 102 Q58 112 50 126" fill="none" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <path d="M210 112 Q196 122 204 136" fill="none" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
''')

ICONS["52_cake_slice"] = wrap_svg('''
  <path d="M48 122 L152 86 L192 114 V178 L48 192 Z" fill="#FEF3C7" stroke="#3B82F6" stroke-width="5" stroke-linejoin="round"/>
  <line x1="48" y1="148" x2="192" y2="136" stroke="#F9A8D4" stroke-width="6"/>
  <line x1="48" y1="168" x2="192" y2="156" stroke="#F9A8D4" stroke-width="6"/>
  <rect x="122" y="56" width="10" height="38" rx="4" fill="#FB7185" stroke="#3B82F6" stroke-width="3"/>
  <ellipse cx="127" cy="44" rx="6" ry="10" fill="#FDE047"/>
  <circle cx="198" cy="172" r="20" fill="#F9A8D4"/>
  <circle cx="192" cy="168" r="2" fill="#FFFFFF"/><circle cx="204" cy="174" r="2" fill="#FFFFFF"/>
''')

ICONS["53_unicorn_float"] = wrap_svg('''
  <ellipse cx="124" cy="154" rx="68" ry="26" fill="#FFFFFF" stroke="#3B82F6" stroke-width="5"/>
  <path d="M168 140 Q176 86 198 86 Q216 86 214 106 Q212 122 188 120" fill="#FFFFFF" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <circle cx="202" cy="96" r="2.5" fill="#3B82F6"/>
  <path d="M194 86 L202 62 L206 86 Z" fill="#FDE047" stroke="#3B82F6" stroke-width="3"/>
  <path d="M174 102 Q164 106 168 114" fill="none" stroke="#FB7185" stroke-width="6" stroke-linecap="round"/>
  <path d="M56 146 Q32 134 38 156 Q44 170 62 162" fill="#FB7185"/>
''')

ICONS["54_bandaid"] = wrap_svg('''
  <rect x="38" y="96" width="180" height="64" rx="32" fill="#FEF3C7" stroke="#3B82F6" stroke-width="6" transform="rotate(-14 128 128)"/>
  <circle cx="72" cy="136" r="8" fill="#FDBA74"/><circle cx="182" cy="112" r="8" fill="#FDBA74"/>
  <rect x="104" y="106" width="48" height="44" rx="8" fill="#FFFFFF" stroke="#3B82F6" stroke-width="4" transform="rotate(-14 128 128)"/>
  <circle cx="120" cy="124" r="3" fill="#3B82F6"/>
  <circle cx="136" cy="120" r="3" fill="#3B82F6"/>
  <path d="M122 132 Q128 138 136 130" fill="none" stroke="#3B82F6" stroke-width="3" stroke-linecap="round"/>
''')

ICONS["55_face_masks"] = wrap_svg('''
  <path d="M98 116 Q84 116 84 128 Q84 140 98 140" fill="none" stroke="#3B82F6" stroke-width="4"/>
  <path d="M194 116 Q208 116 208 128 Q208 140 194 140" fill="none" stroke="#3B82F6" stroke-width="4"/>
  <rect x="106" y="94" width="90" height="64" rx="28" fill="#A6EAF2" stroke="#3B82F6" stroke-width="4"/>
  <path d="M56 128 Q42 128 42 140 Q42 152 56 152" fill="none" stroke="#3B82F6" stroke-width="4"/>
  <path d="M156 128 Q170 128 170 140 Q170 152 156 152" fill="none" stroke="#3B82F6" stroke-width="4"/>
  <rect x="64" y="106" width="94" height="68" rx="30" fill="#FBCFE8" stroke="#3B82F6" stroke-width="4"/>
  <line x1="111" y1="114" x2="111" y2="166" stroke="#3B82F6" stroke-width="3" stroke-linecap="round"/>
''')

ICONS["56_hand_watch_point"] = wrap_svg('''
  <path d="M84 186 L62 112 Q56 90 74 88 Q92 86 106 110 L176 74 Q194 68 196 84 Q198 98 166 116 L166 158 Q166 178 144 186 Z" fill="#FEF9C3" stroke="#3B82F6" stroke-width="8" stroke-linejoin="round"/>
  <rect x="70" y="176" width="84" height="24" rx="8" fill="#1E40AF" transform="rotate(24 112 188)"/>
  <circle cx="112" cy="188" r="14" fill="#FFFFFF" stroke="#1E40AF" stroke-width="4"/>
  <path d="M112 188 V180 M112 188 L118 192" stroke="#1E40AF" stroke-width="3" stroke-linecap="round"/>
''')

ICONS["57_open_hand"] = wrap_svg('''
  <path d="M92 178 L52 136 Q42 122 56 114 Q70 108 88 126 L86 72 Q86 56 100 56 Q112 56 114 82 L124 62 Q132 46 144 50 Q156 54 148 84 L162 66 Q174 54 184 64 Q194 74 176 102 L192 94 Q206 88 208 102 Q210 116 178 136 L156 178 Z" fill="#FEF9C3" stroke="#3B82F6" stroke-width="7" stroke-linejoin="round"/>
  <path d="M104 146 Q124 134 144 144" fill="none" stroke="#3B82F6" stroke-width="4" stroke-linecap="round"/>
  <rect x="76" y="178" width="76" height="28" rx="8" fill="#60A5FA" stroke="#3B82F6" stroke-width="5" transform="rotate(14 114 192)"/>
  <circle cx="136" cy="196" r="3" fill="#1E40AF"/>
''')

ICONS["58_hand_point_up"] = wrap_svg('''
  <path d="M92 192 V132 L106 58 Q112 40 124 44 Q136 48 130 88 L152 96 Q168 102 162 126 L168 148 Q170 176 148 192 Z" fill="#FEF9C3" stroke="#3B82F6" stroke-width="8" stroke-linejoin="round"/>
  <rect x="82" y="188" width="78" height="26" rx="8" fill="#A7F3D0" stroke="#3B82F6" stroke-width="5"/>
  <line x1="96" y1="196" x2="96" y2="206" stroke="#3B82F6" stroke-width="3" stroke-linecap="round"/>
  <line x1="112" y1="196" x2="112" y2="206" stroke="#3B82F6" stroke-width="3" stroke-linecap="round"/>
  <line x1="128" y1="196" x2="128" y2="206" stroke="#3B82F6" stroke-width="3" stroke-linecap="round"/>
  <line x1="144" y1="196" x2="144" y2="206" stroke="#3B82F6" stroke-width="3" stroke-linecap="round"/>
''')

ICONS["59_praying_hands"] = wrap_svg('''
  <!-- Glowing sun behind hands -->
  <circle cx="128" cy="100" r="34" fill="#FDE047"/>
  <!-- Sun rays -->
  <g stroke="#3B82F6" stroke-width="5" stroke-linecap="round">
    <line x1="128" y1="36" x2="128" y2="54"/>
    <line x1="88" y1="48" x2="98" y2="62"/>
    <line x1="168" y1="48" x2="158" y2="62"/>
    <line x1="62" y1="80" x2="80" y2="88"/>
    <line x1="194" y1="80" x2="176" y2="88"/>
    <line x1="56" y1="118" x2="74" y2="118"/>
    <line x1="200" y1="118" x2="182" y2="118"/>
  </g>
  <!-- Left hand (fingers + thumb + palm) -->
  <path d="M90 190 L94 146 Q94 134 102 126 L118 92 Q123 82 128 92 L128 190 Z" fill="#FEF9C3" stroke="#3B82F6" stroke-width="5.5" stroke-linejoin="round"/>
  <path d="M104 164 Q104 138 114 128" fill="none" stroke="#3B82F6" stroke-width="4" stroke-linecap="round"/>
  <!-- Right hand (fingers + thumb + palm) -->
  <path d="M166 190 L162 146 Q162 134 154 126 L138 92 Q133 82 128 92 L128 190 Z" fill="#FEF9C3" stroke="#3B82F6" stroke-width="5.5" stroke-linejoin="round"/>
  <path d="M152 164 Q152 138 142 128" fill="none" stroke="#3B82F6" stroke-width="4" stroke-linecap="round"/>
  <!-- Ruffled cuffs -->
  <path d="M80 190 Q86 182 94 190 Q102 182 110 190 Q118 182 126 190 L124 206 Q102 212 82 206 Z" fill="#FCE7F3" stroke="#3B82F6" stroke-width="4.5" stroke-linejoin="round"/>
  <path d="M130 190 Q138 182 146 190 Q154 182 162 190 Q170 182 176 190 L174 206 Q152 212 132 206 Z" fill="#FCE7F3" stroke="#3B82F6" stroke-width="4.5" stroke-linejoin="round"/>
''')

for name, svg_code in ICONS.items():
    out_path = os.path.join(OUT_DIR, f"{name}.png")
    cairosvg.svg2png(bytestring=svg_code.encode("utf-8"), write_to=out_path, output_width=256, output_height=256)

# Generate HTML preview with embedded base64 PNGs so it works in sandboxed iframe
import base64
cards_html = []
for name in sorted(ICONS.keys()):
    p = os.path.join(OUT_DIR, f"{name}.png")
    with open(p, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("ascii")
    cards_html.append(f'''
    <div class="card">
      <div class="thumb"><img src="data:image/png;base64,{b64}" alt="{name}"/></div>
      <div class="label">{name}.png</div>
    </div>''')

html = f'''<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8"/>
<title>59 Icons – 256×256 Transparent PNG</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f8fafc; color: #0f172a; margin: 0; padding: 24px; }}
  h1 {{ font-size: 22px; margin: 0 0 8px; }}
  p {{ color: #475569; margin: 0 0 24px; font-size: 14px; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 16px; }}
  .card {{ background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 12px; text-align: center; box-shadow: 0 1px 2px rgba(0,0,0,0.04); }}
  .thumb {{
    width: 128px; height: 128px; margin: 0 auto 8px; border-radius: 8px;
    background-image: linear-gradient(45deg, #f1f5f9 25%, transparent 25%),
                      linear-gradient(-45deg, #f1f5f9 25%, transparent 25%),
                      linear-gradient(45deg, transparent 75%, #f1f5f9 75%),
                      linear-gradient(-45deg, transparent 75%, #f1f5f9 75%);
    background-size: 16px 16px;
    background-position: 0 0, 0 8px, 8px -8px, -8px 0;
    display: flex; align-items: center; justify-content: center;
  }}
  .thumb img {{ width: 120px; height: 120px; object-fit: contain; }}
  .label {{ font-size: 11px; color: #334155; word-break: break-all; font-family: ui-monospace, monospace; }}
</style>
</head>
<body>
  <h1>Alle 59 Icons (256×256 px, transparenter Hintergrund)</h1>
  <p>Gespeichert unter <code>/home/user/icons/</code></p>
  <div class="grid">
    {"".join(cards_html)}
  </div>
</body>
</html>'''

with open("/home/user/icons_preview.html", "w", encoding="utf-8") as f:
    f.write(html)

print(f"Generated {len(ICONS)} icons and /home/user/icons_preview.html")
