import os
import base64
import cairosvg

OUT_DIR = "/home/user/icons"
os.makedirs(OUT_DIR, exist_ok=True)

# Import existing ICONS from generate_icons.py, then override/upgrade 33-58 with ultra-detailed versions
from generate_icons import ICONS, wrap_svg

ICONS["33_basketball_motion"] = wrap_svg('''
  <circle cx="140" cy="116" r="76" fill="#FFB36B" stroke="#3B82F6" stroke-width="5"/>
  <path d="M96 58 A62 62 0 0 1 182 62" fill="none" stroke="#FED7AA" stroke-width="6" stroke-linecap="round"/>
  <path d="M92 56 Q146 116 114 186 M72 138 Q140 100 208 134 M124 42 Q178 86 196 164" fill="none" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <line x1="36" y1="184" x2="66" y2="160" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <line x1="52" y1="204" x2="88" y2="176" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <line x1="74" y1="212" x2="98" y2="192" stroke="#3B82F6" stroke-width="4" stroke-linecap="round"/>
''')

ICONS["34_bicycle"] = wrap_svg('''
  <!-- Wheels & spokes -->
  <circle cx="68" cy="156" r="28" fill="none" stroke="#374151" stroke-width="12"/>
  <circle cx="68" cy="156" r="18" fill="none" stroke="#9CA3AF" stroke-width="2"/>
  <circle cx="68" cy="156" r="6" fill="#3B82F6"/>
  <circle cx="186" cy="164" r="28" fill="none" stroke="#374151" stroke-width="12"/>
  <circle cx="186" cy="164" r="18" fill="none" stroke="#9CA3AF" stroke-width="2"/>
  <circle cx="186" cy="164" r="6" fill="#3B82F6"/>
  <!-- Frame -->
  <path d="M68 156 L114 106 L166 112 L134 162 Z" fill="none" stroke="#3B82F6" stroke-width="6" stroke-linejoin="round"/>
  <path d="M166 112 L186 164 M114 106 L86 82 L102 82" fill="none" stroke="#3B82F6" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
  <!-- Pedals & chainring -->
  <circle cx="134" cy="162" r="10" fill="#E5E7EB" stroke="#3B82F6" stroke-width="3"/>
  <path d="M154 98 H182" stroke="#FFB36B" stroke-width="8" stroke-linecap="round"/>
  <line x1="204" y1="198" x2="226" y2="200" stroke="#3B82F6" stroke-width="4" stroke-linecap="round"/>
''')

ICONS["42_sofa_lamp"] = wrap_svg('''
  <!-- Lamp & glow -->
  <polygon points="180,112 216,112 224,142 172,142" fill="#FEF08A" opacity="0.35"/>
  <line x1="198" y1="112" x2="198" y2="190" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <line x1="184" y1="190" x2="212" y2="190" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <path d="M180 112 L188 74 H208 L216 112 Z" fill="#FCE7F3" stroke="#3B82F6" stroke-width="4" stroke-linejoin="round"/>
  <!-- Sofa -->
  <rect x="44" y="114" width="132" height="58" rx="14" fill="#FDE047" stroke="#3B82F6" stroke-width="5"/>
  <line x1="110" y1="114" x2="110" y2="152" stroke="#3B82F6" stroke-width="3"/>
  <rect x="34" y="136" width="22" height="36" rx="8" fill="#FDE047" stroke="#3B82F6" stroke-width="5"/>
  <rect x="164" y="136" width="22" height="36" rx="8" fill="#FDE047" stroke="#3B82F6" stroke-width="5"/>
  <line x1="58" y1="172" x2="58" y2="184" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <line x1="162" y1="172" x2="162" y2="184" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <rect x="64" y="124" width="24" height="24" rx="4" fill="#FB923C" stroke="#3B82F6" stroke-width="3" transform="rotate(15 76 136)"/>
''')

ICONS["51_party_hat"] = wrap_svg('''
  <path d="M128 46 L72 184 Q128 210 184 184 Z" fill="#FDE047" stroke="#3B82F6" stroke-width="6" stroke-linejoin="round"/>
  <path d="M104 106 Q128 118 152 106" fill="none" stroke="#FB923C" stroke-width="6" stroke-linecap="round"/>
  <path d="M88 144 Q128 160 168 144" fill="none" stroke="#FB923C" stroke-width="6" stroke-linecap="round"/>
  <circle cx="116" cy="128" r="4" fill="#3B82F6"/><circle cx="142" cy="126" r="4" fill="#3B82F6"/>
  <circle cx="128" cy="40" r="10" fill="#FB923C" stroke="#3B82F6" stroke-width="3"/>
  <path d="M44 102 Q58 112 50 126" fill="none" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <path d="M210 112 Q196 122 204 136" fill="none" stroke="#3B82F6" stroke-width="5" stroke-linecap="round"/>
  <rect x="52" y="68" width="8" height="8" fill="#F472B6" transform="rotate(20 56 72)"/>
  <rect x="196" y="76" width="8" height="8" fill="#A6EAF2" transform="rotate(-15 200 80)"/>
''')

ICONS["52_cake_slice"] = wrap_svg('''
  <path d="M48 122 L152 86 L192 114 V178 L48 192 Z" fill="#FEF3C7" stroke="#3B82F6" stroke-width="5" stroke-linejoin="round"/>
  <path d="M48 122 L152 86 L192 114 L88 146 Z" fill="#FFFFFF" stroke="#3B82F6" stroke-width="4" stroke-linejoin="round"/>
  <line x1="48" y1="152" x2="192" y2="140" stroke="#F9A8D4" stroke-width="6"/>
  <line x1="48" y1="172" x2="192" y2="160" stroke="#F9A8D4" stroke-width="6"/>
  <rect x="122" y="56" width="10" height="38" rx="4" fill="#FB7185" stroke="#3B82F6" stroke-width="3"/>
  <ellipse cx="127" cy="44" rx="6" ry="10" fill="#FDE047"/>
  <circle cx="198" cy="172" r="20" fill="#F9A8D4" stroke="#3B82F6" stroke-width="3"/>
  <path d="M190 154 L198 146 L206 154" fill="#A7F3A0" stroke="#3B82F6" stroke-width="2.5"/>
  <circle cx="192" cy="168" r="2" fill="#FFFFFF"/><circle cx="204" cy="174" r="2" fill="#FFFFFF"/>
''')

for name, svg_code in ICONS.items():
    out_path = os.path.join(OUT_DIR, f"{name}.png")
    cairosvg.svg2png(bytestring=svg_code.encode("utf-8"), write_to=out_path, output_width=256, output_height=256)

cards_html = []
for name in sorted(ICONS.keys()):
    p = os.path.join(OUT_DIR, f"{name}.png")
    with open(p, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("ascii")
    cards_html.append(f'''
    <div class="card">
      <div class="thumb"><img src="data:image/png;base64,{b64}" alt="{name}"/></div>
      <div class="label">{name}.png</div>
    </div>''')

html = f'''<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8"/>
<title>59 Icons – 256×256 Transparent PNG</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f8fafc; color: #0f172a; margin: 0; padding: 24px; }}
  h1 {{ font-size: 22px; margin: 0 0 8px; }}
  p {{ color: #475569; margin: 0 0 24px; font-size: 14px; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 16px; }}
  .card {{ background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 12px; text-align: center; box-shadow: 0 1px 2px rgba(0,0,0,0.04); }}
  .thumb {{
    width: 128px; height: 128px; margin: 0 auto 8px; border-radius: 8px;
    background-image: linear-gradient(45deg, #f1f5f9 25%, transparent 25%),
                      linear-gradient(-45deg, #f1f5f9 25%, transparent 25%),
                      linear-gradient(45deg, transparent 75%, #f1f5f9 75%),
                      linear-gradient(-45deg, transparent 75%, #f1f5f9 75%);
    background-size: 16px 16px;
    background-position: 0 0, 0 8px, 8px -8px, -8px 0;
    display: flex; align-items: center; justify-content: center;
  }}
  .thumb img {{ width: 120px; height: 120px; object-fit: contain; }}
  .label {{ font-size: 11px; color: #334155; word-break: break-all; font-family: ui-monospace, monospace; }}
</style>
</head>
<body>
  <h1>Alle 59 Icons (256×256 px, transparenter Hintergrund)</h1>
  <p>Gespeichert unter <code>/home/user/icons/</code></p>
  <div class="grid">
    {"".join(cards_html)}
  </div>
</body>
</html>'''

with open("/home/user/icons_preview.html", "w", encoding="utf-8") as f:
    f.write(html)

print(f"Upgraded and rendered {len(ICONS)} icons and /home/user/icons_preview.html")
